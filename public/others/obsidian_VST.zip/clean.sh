#!/bin/sh

rm -f *.exe *.dll *.vst3
